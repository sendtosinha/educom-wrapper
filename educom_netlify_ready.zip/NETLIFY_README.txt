
Educom - Netlify Deployment Ready Package
========================================

This package contains the original Educom HTML template you uploaded, prepared for direct upload to Netlify.

Before deploying:
1) OPTIONAL: If your frontend calls APIs (e.g. fetch('/api/...')), open the template JS files and replace API base paths with your production backend URL.
   - Recommended global replacement example: replace occurrences of "/api/" with "https://api.yourdomain.com/api/"
   - If the template uses a config file (config.js or similar), update API_BASE there.

2) Test locally by opening the template's index.html in a browser. If your site requires API calls, serve via a simple static server:
   - Python: `python3 -m http.server 8000` (run in the template root) then open http://localhost:8000

Deploy to Netlify (drag & drop):
1) Go to https://app.netlify.com/drop (Log in / Sign up first if needed).
2) Drag the CONTENTS of this folder (not the folder itself) into the drop area. Netlify will host it and provide a URL.
3) (Optional) Connect a custom domain in Netlify settings and point DNS to Netlify as instructed.

Deploy to Netlify (Git-based):
1) Create a GitHub repo and push the template files to the repo root.
2) In Netlify, choose 'New site from Git' and connect the repo (select main branch).
3) Build settings: For static HTML/CSS/JS no build command is needed. Set publish directory to the repo root (or the folder that contains index.html).

After deployment:
- You will get a public URL like https://your-site-name.netlify.app
- Use that URL as the `server.url` in the Capacitor wrapper config (capacitor.config.ts)
- Tell me the final URL and I will generate the Android wrapper project and CI pipeline and produce the APK artifacts instructions.

Need help:
- If you want, I can produce a small replacement script to update API base paths automatically across files. Reply "Replace API paths" and I will add it to this package.

Thank you!
