$(document).ready(function(){

	$(".wizard").Turbo({
    	items:1,
    	circular:false
    });
});

$(document).ready(function() {
    $("#productViewer").Turbo({
        items: 1,
        circular: false
    });
});